/**
 * @file: planning_control.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "planning_control/planning_control.hpp"

//global varibles assignment
int global_roadpoint_size = 0;
int global_stoppoint_size = 0;
double global_feedback_steering_angle = 0.0;

//record past path
bool global_path_record_switch = false;
bool global_path_record_time = 0;

DecisionData decisionData;
PostureData postureData;
LidarData lidarData;

//offset
double global_offset_temp_x = INFI;
double global_offset_temp_y = INFI;

/***********debug params***************/
double global_weight_angle = 0.1;
double global_weight_lastangle = 0.5;
double global_weight_anglediff = 0.5;
double global_weight_yawdiff = 0.1;
double global_weight_curvature = 0.2;
double global_weight_error = 0.0;
double global_weight_steeringangle = 0.2;
double global_weight_odomheading = 0.5;


double PREVIEW_SAFE_WIDTH = 0;
double TTC_REDUCE_SPEED_TIME = 0;
double TTC_BRAKE_TIME = 0;
/***********debug params***************/




//all function
bool inArea(const double longitudeX, const double latitudeY, 
	        const double targetX, const double targetY, const double distance)
{
	bool ret = false;

	if (std::abs(longitudeX - targetX) < distance && std::abs(latitudeY - targetY) < distance){
		ret = true;
	}
	else{
		ret = false;
	}

	return ret;
}

void loadRoadPoints(const std::string fileName, std::vector<RoadPoint> &rawRoadPoints)
{
	std::string line;
	std::ifstream fs;

	fs.open(fileName, std::ios::in);
	if (fs.fail()){
		ROS_ERROR("[Z.H]LOAD ROAD POINT FAIL!!!!!!");
	}
	int index = 0;
	while(getline(fs, line))
	{
		if (line.length() > 0){
			RoadPoint roadPoint;
			std::stringstream ss(line);
			
			ss >> roadPoint.road_id >> roadPoint.longitude >> roadPoint.latitude >> roadPoint.courseAngle >> roadPoint.parameter1 >> roadPoint.parameter2 >> roadPoint.parameter3;
		
			roadPoint.index = index;
			rawRoadPoints.push_back(roadPoint);

			index++;
			//std::cout << std::setprecision(15) << roadPoint.road_id << ", " << roadPoint.longitude << ", " << roadPoint.latitude << ", " << roadPoint.courseAngle << ", " << roadPoint.parameter1 << ", "<< roadPoint.parameter2 << ", " << roadPoint.parameter3 << std::endl;
			// finding the minimum longitude and latitude
			if(global_offset_temp_x > roadPoint.longitude)
	        	global_offset_temp_x = roadPoint.longitude;
		    if(global_offset_temp_y > roadPoint.latitude)
		        global_offset_temp_y = roadPoint.latitude;
		}
	}
	
	global_roadpoint_size = rawRoadPoints.size();
	ROS_INFO("[Z.H]roadpoint max index is:%d", index);
	fs.close();
}

void loadStopPoints(const std::string fileName, std::vector<RoadPoint> &rawStopPoints)
{
	  
	std::string line;
    std::ifstream fs;

  	fs.open(fileName, std::ios::in);
	if (fs.fail()){
		ROS_ERROR("[Z.H]LOAD STOP POINT FAIL!!!!!!");
	
	}
	int index = 0;
	while(getline(fs, line))
	{
		if (line.length() > 0){
			RoadPoint roadPoint;
		  	std::stringstream ss(line);

		  	ss >> roadPoint.road_id >> roadPoint.longitude >> roadPoint.latitude >> roadPoint.courseAngle >> roadPoint.parameter1 >> roadPoint.parameter2 >> roadPoint.parameter3;
		  	
		  	roadPoint.index = index;
		  	rawStopPoints.push_back(roadPoint);

		  	index++;
		}
	}

	global_stoppoint_size = rawStopPoints.size();
	ROS_INFO("[Z.H]stoppoint max index is:%d", index);
	fs.close();
}



void buildFinalRoadPoints(std::vector<RoadPoint> &roadPoints, 
			        const std::vector<RoadPoint> &stopPoints)
{
	for(size_t i = 0; i < roadPoints.size(); ++i)
	{
		bool b_foundStopPoint = false;
		for(size_t k = 0; k < stopPoints.size(); ++k)
		{
			bool checkFlag = inArea(roadPoints[i].longitude, roadPoints[i].latitude, stopPoints[k].longitude, stopPoints[k].latitude, stopPoints[k].parameter2);
			if(true == checkFlag) {
          		b_foundStopPoint = true;

		        if(stopPoints[k].parameter1 == 2) {
	            	roadPoints[i].parameter3 = std::fmin(roadPoints[i].parameter3, stopPoints[k].parameter3);
		            roadPoints[i].parameter1 = 2; //station stop
		        }
          		if(stopPoints[k].parameter1 == 3){
            		roadPoints[i].parameter1 = 3;
          		}
        	}
	        else{
	          	if (false == b_foundStopPoint){
	            	roadPoints[i].parameter1 = 0;
	          	}
	        }
		}
	}  
}

void decisionSubCallback(const std_msgs::Float64::ConstPtr &msg, DecisionData *decisionDataPtr)
{
  	decisionDataPtr->current_steering_angle = msg->data;
  	ROS_INFO("[Z.H]received current_steering_angle: %.2f", decisionDataPtr->current_steering_angle);
  	global_feedback_steering_angle = decisionDataPtr->current_steering_angle;
}

void odomCallback(const nav_msgs::Odometry::ConstPtr &odom, PostureData *postureDataPtr, ros::Time *odomReceivedTimePtr)
{
	postureDataPtr->b_isValid = true;
	postureDataPtr->imuData.longitude = odom->pose.pose.position.x;
	postureDataPtr->imuData.latitude = odom->pose.pose.position.y;
	//converting rear axle speed to front axle speed
	if(std::abs(global_feedback_steering_angle/WHEEL_TO_TIRE) >= 3){
		postureDataPtr->imuData.velocity = odom->twist.twist.linear.x/std::cos(global_feedback_steering_angle/WHEEL_TO_TIRE*M_PI/180);//convert to front axle speed
	}
	else{
		postureDataPtr->imuData.velocity = odom->twist.twist.linear.x;
	}

	/*************************normal get yaw *************************/
	/*
	postureDataPtr->imuData.yaw = tf::getYaw(odom->pose.pose.orientation)*180/M_PI;
	if(postureDataPtr->imuData.yaw < 0){
	    while(postureDataPtr->imuData.yaw < 0){
	        postureDataPtr->imuData.yaw += 360;
	    }
	}
	if(postureDataPtr->imuData.yaw > 360){
  		while(postureDataPtr->imuData.yaw > 360){
        	postureDataPtr->imuData.yaw -= 360;
	    }
	} 
	*/

	/**********************low pass filter yaw **********************/
	double yaw_temp = tf::getYaw(odom->pose.pose.orientation)*180/M_PI;//unit:du
	static double lastyaw = yaw_temp;
	if(std::abs(yaw_temp - lastyaw) <= 180)
	{
		postureDataPtr->imuData.yaw = global_weight_odomheading * yaw_temp + (1 - global_weight_odomheading) * lastyaw;
		if(postureDataPtr->imuData.yaw < 0) {
		  	while(postureDataPtr->imuData.yaw < 0){
		    	postureDataPtr->imuData.yaw += 360;
		  	}
		}
		else if(postureDataPtr->imuData.yaw > 360){
		  	while(postureDataPtr->imuData.yaw > 360){
		    	postureDataPtr->imuData.yaw -= 360;
	  		}
		}
		else;
	}
	else
	{
		postureDataPtr->imuData.yaw = yaw_temp;//du
	}
  	lastyaw = postureDataPtr->imuData.yaw;


    /*************************kf filter yaw *************************/
	/*
	double yaw_temp = tf::getYaw(odom->pose.pose.orientation);//rad
	static double lastyaw = yaw_temp;
	// kf filter
	if(std::abs(yaw_temp*180/M_PI - lastyaw*180/M_PI) <= 180)
	{
		double current_yaw = global_weight_odomheading * yaw_temp + 
		                 (1-global_weight_odomheading) * (lastyaw + (std::tan(global_feedback_steering_angle/WHEEL_TO_TIRE*M_PI/180))*(postureDataPtr->imuData.velocity)*0.06/WHEELBASE);
		postureDataPtr->imuData.yaw =  current_yaw*180/M_PI;//du
		if(postureDataPtr->imuData.yaw < 0) {
		  	while(postureDataPtr->imuData.yaw < 0){
		    	postureDataPtr->imuData.yaw += 360;
		  	}
		}
		else if(postureDataPtr->imuData.yaw >= 360){
		  	while(postureDataPtr->imuData.yaw >= 360){
		    	postureDataPtr->imuData.yaw -= 360;
	  		}
		}
		else;
	}
	else
	{
		postureDataPtr->imuData.yaw = yaw_temp*180/M_PI;//du
	}
  	lastyaw = postureDataPtr->imuData.yaw*M_PI/180;
    */

  	ROS_INFO("[Z.H]receive odom postureDataPtr->imuData.yaw:%.f du", postureDataPtr->imuData.yaw);
	
	int gps_state;
	gps_state = odom->pose.pose.position.z; 

	if(gps_state == 4)
	{
		postureDataPtr->imuData.b_isValid = true;					
		//path record
		if(global_path_record_switch == true)
		{
			if(global_path_record_time == 0)
			{
				postureDataPtr->longitude_array.clear();
				postureDataPtr->latitude_array.clear();
				postureDataPtr->yaw_array.clear();
				global_path_record_time = 1;
			}
		  	postureDataPtr->longitude_array.insert(postureDataPtr->longitude_array.begin(), odom->pose.pose.position.x);
		  	postureDataPtr->latitude_array.insert(postureDataPtr->latitude_array.begin(), odom->pose.pose.position.y);
		  	postureDataPtr->yaw_array.insert(postureDataPtr->yaw_array.begin(), postureDataPtr->imuData.yaw);
		  	if(postureDataPtr->longitude_array.size() > PAST_PATH_SIZE)
		  	{
			    postureDataPtr->longitude_array.pop_back();
			    postureDataPtr->latitude_array.pop_back();
			    postureDataPtr->yaw_array.pop_back();
		  	}
		}
		else
		{
			global_path_record_time = 0;
		}
	}
	else
	{
		postureDataPtr->imuData.b_isValid = false;
	}

	*odomReceivedTimePtr = ros::Time::now();
	// ROS_INFO("Odom time: %.3f",odomReceivedTimePtr->toSec());
}

void gridCallback(const nav_msgs::OccupancyGrid::ConstPtr &grid, LidarData *lidarDataPtr, ros::Time *lidarReceivedTimePtr)
{  
    int grid_width = (int)grid->info.width;
    int grid_height = (int)grid->info.height;
    int grid_size = (int)(grid_width * grid_height);
    double grid_resolution = grid->info.resolution;
    double temp_resolution = grid_resolution/2;
    double x_minimum = grid->info.origin.position.x;
    double y_minimum = grid->info.origin.position.y;
    ROS_INFO("[Z.H]received a %d X %d map @ %.3f m/pix, Origin position x: %.3f, y: %.3f ",
              grid_width, grid_height, grid_resolution, x_minimum, y_minimum);

    lidarDataPtr->blockedAreaIndex.clear();
    lidarDataPtr->obstacle_coordinates.clear();
    
    //ROS_INFO("[Z.H]grid size: %d",grid_size);
    if(grid_size > 0){
      for(size_t i = 0; i < grid_size; ++i)
      {
        if(grid->data[i] == 100)
        {
            lidarDataPtr->blockedAreaIndex.push_back(i);
            size_t j = i%grid_width;
            size_t k = i/grid_width;
            Point p_coordinate;
            p_coordinate.x = j * grid_resolution + x_minimum + temp_resolution;
            p_coordinate.y = k * grid_resolution + y_minimum + temp_resolution;
            lidarDataPtr->obstacle_coordinates.push_back(p_coordinate);
        }
        else
            continue;
      }
    }
    ROS_INFO("[Z.H]blockedAreaIndex size:%ld; obstacle_coordinates size:%ld",
             lidarDataPtr->blockedAreaIndex.size(), lidarDataPtr->obstacle_coordinates.size());
    
	lidarDataPtr->b_isValid = true;
    *lidarReceivedTimePtr = ros::Time::now();
}

void roadPointPublisher(ros::Publisher roadPoint_pub, const std::vector<RoadPoint> &RoadPoints)
{
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";
	int size = RoadPoints.size();
	cloud_msg.poses.resize(size);

	for(size_t i = 0; i < size; ++i)
	{
		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(RoadPoints[i].courseAngle-90)/180*M_PI),
                                   tf::Vector3(RoadPoints[i].longitude-global_offset_temp_x, 
                                   	           RoadPoints[i].latitude-global_offset_temp_y, 
                                   	           0)), cloud_msg.poses[i]);
	}

	roadPoint_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]roadPoint publish done~");
}

void pastPathPublisher(ros::Publisher past_path_pub, const PostureData &postureData)
{  
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";

	int size = postureData.longitude_array.size();
	cloud_msg.poses.resize(size);
	
	for(size_t j = 0; j < size; ++j)
	{
		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(postureData.yaw_array[j]-90)/180*M_PI),
		                       tf::Vector3(postureData.longitude_array[j]-global_offset_temp_x, 
		                       	           postureData.latitude_array[j]-global_offset_temp_y,
		                       	           0)), cloud_msg.poses[j]);
	}

	past_path_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]past_path publish done~");
}

double pointDistance(const double x1, const double x2, const double y1, const double y2)
{
	double distance;
	double dX;
	double dY;

	dX = std::abs(x1 - x2);
	dY = std::abs(y1 - y2);
	distance = sqrt(dX * dX + dY * dY);

	return distance;
}

double getAngle (const double x0, const double y0, const double x1, const double y1)
{
	double deltaY = y1 - y0;
	double deltaX = x1 - x0;

	return std::atan2(deltaY, deltaX)*180/M_PI;
}

double getAnglebtwn(const double x1, const double y1, const double x2, const double y2, const double c_a)
{
	// >0 left <0 right
	double a1 = getAngle(x2,y2,x1,y1);
	a1 = 90-a1;
	if(a1<0) 
		a1+=360;
	return c_a-a1;
}


void getCurrentPoint(const double longitude, const double latitude, const double yaw, 
	                 const std::vector<RoadPoint> &roadPoints, DecisionData &decisionData)
{
	int size = roadPoints.size();
	RoadPoint ret;
	// the first search
	if(decisionData.currentpoint_id < 0 || decisionData.currentpoint_id >= size ||
	   decisionData.last_currentpoint_id < 0 || decisionData.last_currentpoint_id >= size) 
	{
		int index_temp = 0;
		double dist = INFI, dist_temp = 0;
		for(size_t i = 0; i < size; ++i)
		{
			dist_temp = pointDistance(longitude, roadPoints[i].longitude, latitude, roadPoints[i].latitude);
			if(dist_temp < dist)
			{
				dist = dist_temp;
				index_temp = i;
			}
		}
		
		decisionData.currentpoint_id = index_temp;
		decisionData.last_currentpoint_id = decisionData.currentpoint_id;
		ROS_INFO("[Z.H]first currentpoint id in roadmap is : %d",decisionData.currentpoint_id);
		ROS_INFO("[Z.H]first currentpoint find in roadmap distance to current pose is : %f", dist);

		//return
		ret = roadPoints[index_temp];
		ret.b_isValid = true;
		if(ret.index != index_temp){
			ROS_ERROR("[Z.H] please check get current point !!! index error???");
		}

		//use for stanley
		ROS_INFO_STREAM("[Z.H] now get the current point is: " 
			<< "long:" << ret.longitude << " lati:" << ret.latitude << " yaw:" << ret.courseAngle);
		double a_b = getAnglebtwn(longitude, latitude, ret.longitude, ret.latitude, ret.courseAngle);

	    if(a_b >= 0)
	      	ret.lateral_dist = dist;
	    else
	      	ret.lateral_dist = -dist;
	}

	// not the first search
	else 
	{
		int index_temp = 0;
		double dist = INFI, dist_temp = 0;
		int begin = decisionData.last_currentpoint_id;

		if(begin >= 100) {
			for(int j = begin-100; j < begin+200; ++j) {
				dist_temp = pointDistance(longitude, roadPoints[j].longitude, latitude, roadPoints[j].latitude);
				if(dist_temp < dist) {
					dist = dist_temp;
					index_temp = j;
				}
			}
		}
		else {
			for(int j = 0; j < begin+200; ++j) {
				dist_temp = pointDistance(longitude, roadPoints[j].longitude, latitude, roadPoints[j].latitude);
				if(dist_temp < dist) {
					dist = dist_temp;
					index_temp = j;
				}
			}
		}
		//judge
		if(dist < MIN_DISTANCE_TO_POSE)
		{
			decisionData.currentpoint_id = index_temp;
			decisionData.last_currentpoint_id = decisionData.currentpoint_id;
			ROS_INFO("[Z.H]currentpoint id in roadmap is : %d",decisionData.currentpoint_id);
			ROS_INFO("[Z.H]currentpoint find in roadmap distance to current pose is : %f", dist);

			//return
			ret = roadPoints[index_temp];
			ret.b_isValid = true;
			if(ret.index != index_temp){
				ROS_ERROR("[Z.H] please check get current point !!! index error???");
			}
		}
		else
		{
			ROS_WARN("[Z.H]currentpoint is not find in roadmap,and distance to current pose is : %f", dist);
			decisionData.currentpoint_id = begin;
			decisionData.last_currentpoint_id = decisionData.currentpoint_id;
			//return
			ret = roadPoints[begin];
			ret.b_isValid = false;
			if(ret.index != begin){
				ROS_ERROR("[Z.H] please check get current point !!! index error???");
			}
		}

		//use for stanley
		ROS_INFO_STREAM("[Z.H] now get the current point is: " 
			<< "long:" << ret.longitude << " lati:" << ret.latitude << " yaw:" << ret.courseAngle);
		double a_b = getAnglebtwn(longitude, latitude, ret.longitude, ret.latitude, ret.courseAngle);

	    if(a_b >= 0)
	      	ret.lateral_dist = dist;
	    else
	      	ret.lateral_dist = -dist;
	}
	//assignment
	decisionData.currentPoint = ret;
}

void currentPointPublisher(ros::Publisher currentPoint_pub, const DecisionData &decisionData)
{
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";

	RoadPoint currentPoint_temp = decisionData.currentPoint;
	if(currentPoint_temp.b_isValid == true)
	{
		cloud_msg.poses.resize(1);
  		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(currentPoint_temp.courseAngle-90)/180*M_PI),
                                   tf::Vector3(currentPoint_temp.longitude-global_offset_temp_x,
                                               currentPoint_temp.latitude-global_offset_temp_y, 
                                               0)), cloud_msg.poses[0]);

	}
	currentPoint_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]currentPoint publish done~");
}

/**
 * @brief  getAngleDiff
 * @param  ang0: yaw  0 ~ 360;
 * @param  ang1: current angle:  -180 ~ 180
 */
double getAngleDiff (double ang0, double ang1)
{
	if (ang0 > 180) {
		ang0 = ang0 - 360;
	}

	ang0 = -ang0;
	ang1 = ang1 - 90;

	if (ang1 < -180) {
		ang1 = ang1 + 360;
	}
	
	double ret = ang1 - ang0;
	if (ret > 180) {
		ret = ret - 360;
	}
	else if (ret < -180){
		ret = ret + 360;
	}
	
	return ret;
}

/**
 * @brief  getYawDiff
 * @param  yawVehicle: 0 ~ 360;
 * @param  yawRoad: 0 ~ 360
 */
double getYawDiff (double yawVehicle, double yawRoad)
{
	if (yawVehicle > 180) {
		yawVehicle = yawVehicle - 360;
	}
	else;
	yawVehicle = -yawVehicle;

	if (yawRoad > 180) {
		yawRoad = yawRoad - 360;
	}
	else;
	yawRoad = -yawRoad;

	double ret = yawRoad - yawVehicle;

	if (ret > 180) {
		ret = ret - 360;
	}
	else if (ret < -180){
		ret = ret + 360;
	}
	else;

	return ret;
}

double stanley(const RoadPoint &currentPoint, const double &yawDiff, const double &velocity)
{
	double ksoft = 1;

	static double l_y = 0;
	double inner = KDStanley * (-currentPoint.lateral_dist) / (ksoft + velocity);
	double s_angle = yawDiff + StanleyYKD * (yawDiff - l_y)/0.1 + StanleyPDist * atan(inner);
	l_y = yawDiff;

	return s_angle;
}


void getSteeringAngle(const double longitude, const double latitude, const double yaw, 
	                  const double velocity, DecisionData &decisionData)
{
	if(decisionData.currentPoint.b_isValid == true)
	{
		decisionData.currentState = 1;//follow roadmap

		double currentAngle = 0.0;
		if (false == decisionData.b_takingOver){
	        currentAngle = getAngle(longitude, latitude, decisionData.currentPoint.longitude, decisionData.currentPoint.latitude);
	        ROS_INFO("[Z.H]now following normal lane.");
      	}
      	else// during taking over
      	{
      		ROS_INFO("[Z.H]now is takingover and following left lane.");
      	}

      	/**
      	 * @brief  calculate anglediff and yawdiff
      	 * @param  anglediff: the angle difference between the car current pose(x,y) and the nearest point(x,y) in roadmap 
      	 * @param  yawdiff: the yaw difference between the car yaw(yaw) and the nearest point yaw(yaw) in roadmap
      	 */
      	static double last_angleDiff = 0;
      	double angleDiff = getAngleDiff(yaw, currentAngle);

		static double last_yawDiff = 0;
		static double last_courseAngle = 0;
		static double llast_courseAngle = 0;
		double currentCourseAngle = 0;
		currentCourseAngle = global_weight_angle * decisionData.currentPoint.courseAngle + (1 - global_weight_angle)* last_courseAngle;
		last_courseAngle = currentCourseAngle;
		currentCourseAngle = global_weight_lastangle * currentCourseAngle + (1 - global_weight_lastangle) * llast_courseAngle;
		llast_courseAngle = currentCourseAngle;
		double yawDiff = getYawDiff(yaw, currentCourseAngle);

		// smooth and filter
		angleDiff = global_weight_anglediff * angleDiff  + (1 - global_weight_anglediff) * last_angleDiff;
		last_angleDiff = angleDiff;

		yawDiff = global_weight_yawdiff * yawDiff  + (1 - global_weight_yawdiff) * last_yawDiff;
		last_yawDiff = yawDiff;

		//calculate the global_weight_error
		static double last_c_cur = 0;
		double c_cur = global_weight_curvature * decisionData.currentPoint.parameter2 + (1 - global_weight_curvature) * last_c_cur;
		last_c_cur = c_cur;
		if(std::abs(c_cur) >= 0.5){
			global_weight_error = 0.05;
		}
		else{
			global_weight_error += 0.001;
			if(global_weight_error > 0.5)
				global_weight_error = 0.5;
		}

		// main stanley
		double error_a = (angleDiff * (1 - global_weight_error) + yawDiff * global_weight_error);
		double s_angle = stanley(decisionData.currentPoint, error_a, velocity);
		s_angle *= WHEEL_TO_TIRE;
		static double last_s_angle = 0;
		s_angle = global_weight_steeringangle * s_angle + (1 - global_weight_steeringangle) * last_s_angle;
		last_s_angle = s_angle;
		ROS_INFO("[Z.H][stanley]calculate target steering angle is:%f", s_angle);
		decisionData.targetSteeringAngle = s_angle + STEERING_ANGLE_ADJUST;

		decisionData.targetSteeringVelocity = std::abs(angleDiff)*140/90+300;
		if(decisionData.targetSteeringVelocity < 5)
			decisionData.targetSteeringVelocity  = 5;
		ROS_INFO("[Z.H][stanley]calculate target steering velocity is:%f", decisionData.targetSteeringVelocity);

        /**
         * @brief set the default target speed
         */
		double targetSpeed = 0;
		targetSpeed = decisionData.currentPoint.parameter3;
      	if(targetSpeed > (8/3.6) && velocity < (5/3.6))
        	targetSpeed = 8/3.6; // avoid jerking at start
        decisionData.targetSpeed = targetSpeed;
        ROS_INFO("[Z.H][stanley]set the default targetspeed is:%f", decisionData.targetSpeed);
	}
	else
	{
		decisionData.currentState = 0;
	}
}

void mapJudge(DecisionData &decisionData)
{
	decisionData.b_takeOverEnable = false;
	decisionData.b_redLightStopped = false;
	decisionData.stationStopFlag = false; //station stop

	decisionData.targetSpeed = std::fmin(decisionData.targetSpeed, decisionData.currentPoint.parameter3);

	if (decisionData.currentPoint.parameter1 == 1){
		ROS_WARN("[Z.H]this is traffic light point!!!");
	}
	else if(decisionData.currentPoint.parameter1 == 2){//station stop
		ROS_WARN("[Z.H]this is station stop point!!!");
		decisionData.stationStopFlag = true; 
	}
	else if(decisionData.currentPoint.parameter1 == 3){
		ROS_WARN("[Z.H]this is overtaking enabled point!!!");
		decisionData.b_takeOverEnable = true;
	}
	else;
}

void paramsAdjustByVehicleSpeed(const DecisionData &decisionData)
{
	if(decisionData.velocity*3.6 > 30)
	{
		PREVIEW_SAFE_WIDTH = 3;
		TTC_REDUCE_SPEED_TIME = 5;
		TTC_BRAKE_TIME = 3.2;
	}
	else if(decisionData.velocity*3.6 > 20)
	{
		PREVIEW_SAFE_WIDTH = 2.6;
		TTC_REDUCE_SPEED_TIME = 4.5;
		TTC_BRAKE_TIME = 2.8;
	}
	else if(decisionData.velocity*3.6 > 10)
	{
		PREVIEW_SAFE_WIDTH = 2.2;
		TTC_REDUCE_SPEED_TIME = 4;
		TTC_BRAKE_TIME = 2.5;
	}
	else if(decisionData.velocity*3.6 > 8)
	{
		PREVIEW_SAFE_WIDTH = 1.8;
		TTC_REDUCE_SPEED_TIME = 3.5;
		TTC_BRAKE_TIME = 2.2;
	}
	else if(decisionData.velocity*3.6 > 5)
	{
		PREVIEW_SAFE_WIDTH = 1.5;
		TTC_REDUCE_SPEED_TIME = 3;
		TTC_BRAKE_TIME = 1.9;
	}
	else if(decisionData.velocity*3.6 > 3)
	{
		PREVIEW_SAFE_WIDTH = 1.2;
		TTC_REDUCE_SPEED_TIME = 2.5;
		TTC_BRAKE_TIME = 1.6;
	}
	else
	{
		PREVIEW_SAFE_WIDTH = 1;
		TTC_REDUCE_SPEED_TIME = 2;
		TTC_BRAKE_TIME = 1.3;
	}  
}

void accLimiter(double &advisedSpeed, double &advisedSpeedTakeOver, DecisionData &decisionData)
{
	if(decisionData.velocity*3.6 > 20 && (advisedSpeed-decisionData.last_advisedSpeed) > (0.5/3.6)){
		advisedSpeed = decisionData.last_advisedSpeed + (0.5/3.6);
	}
	else if(decisionData.velocity*3.6 > 15 && (advisedSpeed-decisionData.last_advisedSpeed) > (0.4/3.6)){
		advisedSpeed = decisionData.last_advisedSpeed + (0.4/3.6);
	}
	else if(decisionData.velocity*3.6 > 10 && (advisedSpeed-decisionData.last_advisedSpeed) > (0.3/3.6)){
		advisedSpeed = decisionData.last_advisedSpeed + (0.3/3.6);
	}
	else if((advisedSpeed-decisionData.last_advisedSpeed) > (0.2/3.6)){
		advisedSpeed = decisionData.last_advisedSpeed + (0.2/3.6);
	}
	else;

	if(decisionData.velocity*3.6 > 20 && (advisedSpeed-decisionData.last_advisedSpeedTakeOver) > (0.5/3.6)){
		advisedSpeedTakeOver = decisionData.last_advisedSpeedTakeOver + (0.5/3.6);
	}
	else if(decisionData.velocity*3.6 > 15 && (advisedSpeed-decisionData.last_advisedSpeedTakeOver) > (0.4/3.6)){
		advisedSpeedTakeOver = decisionData.last_advisedSpeedTakeOver + (0.4/3.6);
	}
	else if(decisionData.velocity*3.6 > 10 && (advisedSpeed-decisionData.last_advisedSpeedTakeOver) > (0.3/3.6)){
		advisedSpeedTakeOver = decisionData.last_advisedSpeedTakeOver + (0.3/3.6);
	}
	else if((advisedSpeed-decisionData.last_advisedSpeedTakeOver) > (0.2/3.6)){
		advisedSpeedTakeOver = decisionData.last_advisedSpeedTakeOver + (0.2/3.6);
	}
	else;

	decisionData.last_advisedSpeed = advisedSpeed;
	decisionData.last_advisedSpeedTakeOver = advisedSpeedTakeOver;

}


void getTargetSpeed(DecisionData &decisionData, PostureData &postureData, LidarData &lidarData)
{
	double judgeSpeed = (decisionData.targetSpeed > MAX_SPEED) ? MAX_SPEED : decisionData.targetSpeed;
  	judgeSpeed = (decisionData.targetSpeed < MIN_SPEED) ? MIN_SPEED : decisionData.targetSpeed;
  	double advisedSpeed = judgeSpeed;
  	double advisedSpeedTakeOver = judgeSpeed;

	paramsAdjustByVehicleSpeed(decisionData);

	ROS_INFO("[Z.H]now receive wheel steering angle feedback:%f du", decisionData.current_steering_angle);
	double tire_angle_feedback = global_feedback_steering_angle/WHEEL_TO_TIRE;
	ROS_INFO("[Z.H]now receive tire angle feedback:%f du", tire_angle_feedback);
	double tire_angle_feedback_rad = tire_angle_feedback*M_PI/180;
	double current_v_front = postureData.imuData.velocity;//front wheel speed ::the previous conversion has been made
	// double current_v_back = postureData.imuData.velocity;//back wheel speed
	// double current_v_front = current_v_back/(std::cos(tire_angle_feedback_rad));//front wheel speed

	if(std::abs(tire_angle_feedback) > 0.6)
	{
		double r_front = WHEELBASE/std::sin(tire_angle_feedback_rad);
		double r_back = r_front*(std::cos(tire_angle_feedback_rad));

		Point circle_point;//center of circle
		circle_point.x = r_back;
		circle_point.y = -WHEELBASE;

		double angular_speed = current_v_front/(std::fabs(r_front));//rad/s
		ROS_INFO("[Z.H]current angular_speed:%f", angular_speed);
		double r_min = (std::fabs(r_back)) - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double r_max = (std::fabs(r_front)) + CAR_WIDTH + PREVIEW_SAFE_WIDTH;

		std::vector<double> v_ttc;
		if(!lidarData.obstacle_coordinates.empty()) 
		{
		    int len = lidarData.obstacle_coordinates.size();

		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        double r_temp = sqrt((p_x - circle_point.x)*(p_x - circle_point.x) + (p_y - circle_point.y)*(p_y - circle_point.y));
		        
		        if(r_temp <= r_max && r_temp >= r_min){
		            double alpha = std::atan2(p_y + WHEELBASE,std::fabs(r_back - p_x));//rad
		            if(alpha > std::fabs(tire_angle_feedback_rad)){
		                double ttc = (alpha - std::fabs(tire_angle_feedback_rad))/angular_speed;
		                v_ttc.push_back(ttc);
		            }   
		        }
		    }

		    double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    ROS_INFO("[Z.H]when tire_angle_feedback is useful,now ttc_min:%f",ttc_min);
		    if(ttc_min <= TTC_REDUCE_SPEED_TIME)
		    {
		        advisedSpeed += (-0.1)*MAX_DE_ACC;
		        if(advisedSpeed < 0.1){
		            advisedSpeed = 0.0;
		        }
		    }
		    if(ttc_min <= TTC_BRAKE_TIME)
		        advisedSpeed = 0.0;
		}
		else
		{
		    advisedSpeed = judgeSpeed;
		}
	}

	//std::fabs(tire_angle_feedback)<2.0
	else
	{
		double min_x = 0.0 - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double max_x = 0.0 + CAR_WIDTH + PREVIEW_SAFE_WIDTH;
		double min_y = 0.0;
		double max_y = 7.5;
		std::vector<double> v_ttc;
		if(!lidarData.obstacle_coordinates.empty()) 
		{
		    int len = lidarData.obstacle_coordinates.size();

		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        if(p_x <= max_x && p_x >= min_x && p_y <= max_y && p_y >= min_y){
		            double ttc = std::fabs(p_y)/current_v_front;
		            v_ttc.push_back(ttc);
		        }
		    }

		    double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    ROS_INFO("[Z.H]when tire_angle_feedback is too small and is invalid, now ttc_min:%f",ttc_min);
		    if(ttc_min <= TTC_REDUCE_SPEED_TIME)
		    {
		        advisedSpeed += (-0.1)*MAX_DE_ACC;
		        if(advisedSpeed < 0.1){
		            advisedSpeed = 0.0;
		        }
		    }
		    if(ttc_min <= TTC_BRAKE_TIME)
		        advisedSpeed = 0.0;
		}
		else
		{
		    advisedSpeed = judgeSpeed;
		}
	}
	ROS_INFO("[Z.H]original judgeSpeed:%f m/s", judgeSpeed);
	ROS_INFO("[Z.H]NOW advisedSpeed:%f m/s", advisedSpeed);

	//limit acceleration
  	accLimiter(advisedSpeed, advisedSpeedTakeOver, decisionData);
  	ROS_INFO("[Z.H]NOW after acc limiter advisedSpeed:%f km/h", advisedSpeed*3.6);

  	//speed assignment 
	if(decisionData.b_takeOverEnable == false) 
	{
		decisionData.b_takingOver = false;
		if(advisedSpeed < judgeSpeed )
		{
			if (decisionData.targetSpeed > advisedSpeed)
			{
				decisionData.targetSpeed = advisedSpeed;
				ROS_INFO("[Z.H]speed limited because of obstacle~");
			}
		}
	}
	if(decisionData.b_takeOverEnable == true)
	{
		ROS_INFO("[Z.H]NOW currentpoint in roadmap is overtaking enabled~~");
		if(decisionData.b_takingOver == false)// not in overtaking
		{ 

		}
		else
		{

		}
	}
	
}
