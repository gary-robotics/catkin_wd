/**
 * @file: planning_control_sub_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "planning_control/planning_control.hpp"


void chatterCallback(const std_msgs::Float64::ConstPtr &msg)
{
	ROS_INFO("I heard: [%.3f]", msg->data);
}

int main(int argc, char *argv[])
{
	
	ros::init(argc, argv, "planning_control_sub_node");

	ros::NodeHandle n;

	
	ros::Subscriber sub = n.subscribe<std_msgs::Float64>("decision_sub", 1, chatterCallback);

	ros::spin();

	return 0;
}
