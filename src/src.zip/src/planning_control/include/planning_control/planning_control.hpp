/**
 * @file: planning_control.hpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#pragma once

//C++
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <math.h>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <mutex>
#include <omp.h>
#include <algorithm>
#include <cstdlib>
#include <map>
#include <boost/bind.hpp>
#include <boost/timer.hpp>
#include <boost/thread/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

//ROS
#include <ros/ros.h>
#include <ros/package.h>
#include "ros/assert.h"
#include <tf/tf.h>
#include "Eigen/Dense"

// msgs
#include <std_msgs/Header.h>
#include <sensor_msgs/PointCloud2.h>
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Float64MultiArray.h"
#include "nav_msgs/Odometry.h"
#include <nav_msgs/OccupancyGrid.h>
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "geometry_msgs/PoseArray.h"
#include "geometry_msgs/Pose.h"



// pcl
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#include <pcl/common/common.h>
#include <pcl/common/centroid.h>
#include <pcl_ros/transforms.h>
#include <pcl/search/organized.h>
#include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/ModelCoefficients.h>

#include <pcl/conversions.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/filters/filter.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/crop_box.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/extract_indices.h>

#include <pcl/sample_consensus/method_types.h>  
#include <pcl/sample_consensus/model_types.h>  
#include <pcl/segmentation/extract_clusters.h>  
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/conditional_euclidean_clustering.h>

//define
#define PAST_PATH_SIZE 100
#define INFI 1000000000
#define MIN_DISTANCE_TO_POSE 10
#define MAX_SPEED 60 / 3.6 // m/s
#define MIN_SPEED 5 / 3.6 // m/s

/***********debug define params***************/
#define WHEEL_TO_TIRE 26  //wheel to tire
#define WHEELBASE 5.8   //wheelbase
#define CAR_WIDTH 1.25 //half of car width
#define MAX_DE_ACC 1.5  //(m/s^2) maximum de-acceleration

#define KDStanley 4      //old10
#define StanleyPDist 1    //old2
#define StanleyYKD 2  //old1
#define P_dist_stanley 1.5 
#define STEERING_ANGLE_ADJUST 3
/***********debug define params***************/


//typedefine struct
struct Point{
	
	double x;
	double y;
	double angle;
};

struct RoadPoint{

	bool b_isValid = false;

	int road_id;//as matlab p1 p2 p3 ... number of Road
	int index = 0;//order number
	double longitude = 0.0;
	double latitude = 0.0;
	double courseAngle = 0.0;//heading

	int parameter1;// 0 normal point;1 traffic light point; 2 stop station point 3 enable avoid obstacle
	double parameter2 = 0.0;//curvature
	double parameter3 = 0.0;//max speed
	//stanley use
	double lateral_dist = 0;


	//dispense
	double distance = 0.0;
	double preview_dist = 0;	
	uint32_t totalIndex = 0;
	int16_t roadType = 0;
	double height = 0.0;	
	double a_b = 0;
};

struct DecisionData{

	bool b_isValid = false;
	bool b_takeOverEnable = false;
	bool b_takingOver = false;
	bool b_comingBack = false;
	bool b_redLightStopped = false;	
	bool stationStopFlag = false; //station stop

	
	RoadPoint currentPoint; // point in roadmap
	int currentpoint_id = INFI;
	int last_currentpoint_id = INFI;

	RoadPoint currentPosture; // real point
	int targetWorkMode = 0;
	int currentState = 0; // 0 initial 1 follow roadmap 2 stop waiting
	double velocity = 0;
	double targetSteeringAngle = 0.0;
	double targetSteeringVelocity = 0.0;
	double targetSpeed = 0.0;
	double current_steering_angle = 0.0;
	double last_advisedSpeed = 0; //last speed for lidar judge
	double last_advisedSpeedTakeOver = 0; //last speed for lidar judge
	

	//dispense
	bool b_onRoadPoint = false;
	RoadPoint previewPoint;
	RoadPoint previewPointTakeOver;
	double targetThrottle = 0.0;
	double throttleIntegral = 0.0;
	double targetBrakePressure = 0.0;
	double previewDistance = 0.0;
	uint8_t targetGearPosition = 0;
	int16_t targetAccLevel = 2; //acc normal
	
	int32_t currentId = 0;
	int32_t currentIndex = 0;
	int32_t currentTotalIndex = 0;
	int32_t roadType = 0;
	int32_t nextId = 0;
	int32_t nextNextId = 0;
	uint16_t postureSensorMode = 0;	
	uint16_t pathNumber = 0;
	boost::posix_time::ptime takingOverTimeCounter;
	bool b_isAlive;
	double targetSpeedTest = 0;
};

struct ImuData{

	bool b_isValid = false;

	double longitude = 0.0;
	double latitude = 0.0;
	double yaw = 0.0;

	double velocity = 0.0;

	//dispense
	double roll;
	double pitch;
	double yawRate = 0.0;	
};

struct PostureData{

	bool b_isValid = false;

  	ImuData imuData;
  
  	std::vector<double> longitude_array;
  	std::vector<double> latitude_array;
  	std::vector<double> yaw_array;  	
};

struct LidarData{

	bool b_isValid = false;

	std::vector<int> blockedAreaIndex;
	std::vector<Point> obstacle_coordinates;	
};


//global varibles state
//roadpoint stoppoint
extern int global_roadpoint_size;
extern int global_stoppoint_size; 
extern double global_feedback_steering_angle;

//record past path
extern bool global_path_record_switch;
extern bool global_path_record_time;

extern DecisionData decisionData;
extern PostureData postureData;
extern LidarData lidarData;

//offset
extern double global_offset_temp_x;
extern double global_offset_temp_y;

/***********debug params***************/
extern double global_weight_angle;
extern double global_weight_lastangle;
extern double global_weight_anglediff;
extern double global_weight_yawdiff;
extern double global_weight_curvature;
extern double global_weight_error;
extern double global_weight_steeringangle;
extern double global_weight_odomheading;


extern double PREVIEW_SAFE_WIDTH;
extern double TTC_REDUCE_SPEED_TIME;
extern double TTC_BRAKE_TIME;
/***********debug params***************/










// functions
bool inArea(const double longitudeX, const double latitudeY, 
	        const double targetX, const double targetY, const double distance);

void loadRoadPoints(const std::string fileName, std::vector<RoadPoint> &rawRoadPoints);

void loadStopPoints(const std::string fileName, std::vector<RoadPoint> &rawStopPoints);

void buildFinalRoadPoints(std::vector<RoadPoint> &roadPoints, 
			        const std::vector<RoadPoint> &stopPoints);

void decisionSubCallback(const std_msgs::Float64::ConstPtr &msg, DecisionData *decisionDataPtr);

void odomCallback(const nav_msgs::Odometry::ConstPtr &odom, PostureData *postureDataPtr, ros::Time *odomReceivedTimePtr);

void gridCallback(const nav_msgs::OccupancyGrid::ConstPtr &grid, LidarData *lidarDataPtr, ros::Time *lidarReceivedTimePtr);

void roadPointPublisher(ros::Publisher roadPoint_pub, const std::vector<RoadPoint> &RoadPoints);

void pastPathPublisher(ros::Publisher past_path_pub, const PostureData &postureData);

double pointDistance(const double x1, const double x2, const double y1, const double y2);

double getAngle (const double x0, const double y0, const double x1, const double y1);

double getAnglebtwn(const double x1, const double y1, const double x2, const double y2, const double c_a);

void getCurrentPoint(const double longitude, const double latitude, const double yaw, 
	                 const std::vector<RoadPoint> &roadPoints, DecisionData &decisionData);

void currentPointPublisher(ros::Publisher currentPoint_pub, const DecisionData &decisionData);

double getAngleDiff (double ang0, double ang1);

double getYawDiff (double yawVehicle, double yawRoad);

double stanley(const RoadPoint &currentPoint, const double &yawDiff, const double &velocity);

void getSteeringAngle(const double longitude, const double latitude, const double yaw, 
	                  const double velocity, DecisionData &decisionData);

void mapJudge(DecisionData &decisionData);

void paramsAdjustByVehicleSpeed(const DecisionData &decisionData);

void accLimiter(double &advisedSpeed, double &advisedSpeedTakeOver, DecisionData &decisionData);

void getTargetSpeed(DecisionData &decisionData, PostureData &postureData, LidarData &lidarData);




