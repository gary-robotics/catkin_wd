/**
 * @file: map_builder_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
//ROS
#include <ros/ros.h>
#include <ros/package.h>
#include "ros/assert.h"
#include <tf/tf.h>
#include "nav_msgs/Odometry.h"
#include <nav_msgs/OccupancyGrid.h>

//C++
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <math.h>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>


std::string rawMap_path = "";


void odomCallback(const nav_msgs::Odometry::ConstPtr &msg)
{
	//ROS_INFO("Z.H start odomCallback~");
	double longitude = msg->pose.pose.position.x;
	double latitude = msg->pose.pose.position.y;
	double yaw = tf::getYaw(msg->pose.pose.orientation)*180/M_PI;

	static std::ofstream fsRoad(rawMap_path, std::ofstream::trunc);

	fsRoad << std::setprecision(15) << 1 << " " << longitude << " " << latitude << " " << yaw << " " << 4 << " " << 0 << std::endl;

}

int main(int argc, char *argv[])
{

	ros::init(argc, argv, "map_builder_node");

	ros::NodeHandle n;

	// define package path
	std::string path = ros::package::getPath("map_builder");
	rawMap_path = path+"/map/rawMap.txt";

	ROS_INFO("[Z.H]Package path: %s\n",rawMap_path.c_str());

	ros::Subscriber odom_sub = n.subscribe<nav_msgs::Odometry>("odom", 1, odomCallback);

	ros::spin();

	return 0;
}