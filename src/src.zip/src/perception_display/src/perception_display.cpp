/**
 * @file: perception_display.cpp
 * @author: Z.H
 * @date: 2019.05.9
 */
#include "perception_display/perception_display.h"

static bool point_cmp(const pcl::PointXYZ &a, const pcl::PointXYZ &b)
{
    return a.z < b.z;
}


PerceptionDisplay::PerceptionDisplay():point_cloud_(new PointCloud()),
									    seed_cloud_(new PointCloud()),
								      ground_cloud_(new PointCloud()),
			  					   no_ground_cloud_(new PointCloud()),
			  					 unsegmented_cloud_(new PointCloud()){
	ROS_WARN("begin to perception display!");

	//get params
	n_.getParam("/perception_display/point_cloud_topic", point_cloud_topic_);
	n_.getParam("/perception_display/no_ground_topic", no_ground_topic_);
	n_.getParam("/perception_display/detecting_bbox_topic", detecting_bbox_topic_);
	n_.getParam("/perception_display/lidar_height", lidar_height_);

	//initialize cluster segment
	seg_distance_ = {10, 20, 30, 40};
    cluster_distance_ = {0.5, 1.0, 1.5, 2.0, 2.5};
    height_threshold_ = 1.2 * lidar_height_;
  
    //sub and pub
    point_cloud_sub_ = n_.subscribe(point_cloud_topic_, 10, 
    	               &PerceptionDisplay::subPointCloudCallback, this);
    no_ground_pub_ = n_.advertise<sensor_msgs::PointCloud2>(no_ground_topic_, 10, this);
    detecting_bbox_pub_ = n_.advertise<jsk_recognition_msgs::BoundingBoxArray>(detecting_bbox_topic_, 10, this);

    ros::spin();
}

PerceptionDisplay::~PerceptionDisplay() {

}


void PerceptionDisplay::subPointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr &msg)
{
    ros::Time begin = ros::Time::now(); 
	pcl::fromROSMsg(*msg, *point_cloud_);

	if(!point_cloud_->points.empty()) {

		/*-----------------------------main loop--------------------------------*/
		/*----------Removing Ground Clustering Obstacles and Segmenting---------*/

        //1. Its begin to ground plane fitting and remove the ground pointcloud
        //sort on Z-axis value.
		std::sort(point_cloud_->points.begin(), point_cloud_->points.end(), point_cmp);
		
		//2. Extract init ground seeds.
	    //LPR is the mean of low point representative
	    double sum = 0;
	    int cnt = 0;
	    //calculate the mean height value.
	    for (size_t i = 0; i < point_cloud_->points.size() && cnt < 25; ++i) {
	        sum += point_cloud_->points[i].z;
	        ++cnt;    
	    }
	    double lpr_height = (cnt != 0 ? sum / cnt : 0); // in case divide by 0
	    seed_cloud_->clear();
	    ground_cloud_->clear();
	    //iterate pointcloud, filter those height is less than lpr.height+th_seeds_
	    #pragma omp parallel for
	    for (size_t i = 0; i < point_cloud_->points.size(); ++i)
	    {
	        if (point_cloud_->points[i].z < lpr_height + 1.2)
	        {
	            seed_cloud_->points.push_back(point_cloud_->points[i]);
	        }
	    }
	    pcl::copyPointCloud(*seed_cloud_, *ground_cloud_); //copy
	   	ROS_WARN("seed_cloud size: %ld ", seed_cloud_->points.size());
	   	//ROS_INFO("ground_cloud size: %ld ", ground_cloud_->points.size());

	    // 3. Ground plane fitter mainloop
	    for (size_t i = 0; i < 4; ++i)//num_iter = 4
	    {
	        //create covarian matrix in single pass.
		    Eigen::Matrix3f cov;
		    Eigen::Vector4f pc_mean;
		    pcl::computeMeanAndCovarianceMatrix(*ground_cloud_, cov, pc_mean);
		    //Singular Value Decomposition: SVD
		    Eigen::JacobiSVD<Eigen::MatrixXf> svd(cov, Eigen::DecompositionOptions::ComputeFullU);
		    //use the least singular vector as normal
		    normal_ = (svd.matrixU().col(2));
		    //std::cout << "normal:" << normal_.matrix() << std::endl;
		    // mean ground seeds value
		    Eigen::Vector3f seeds_mean = pc_mean.head<3>();
		    // according to normal.T*[x,y,z] = -d
		    d_ = -(normal_.transpose() * seeds_mean)(0, 0);
		    // set distance threhold to `th_dist - d`
		    th_dist_d_ = 0.3 - d_;
		    //ROS_WARN_STREAM("d_ = " << d_ << "; th_dist_d_ = " << th_dist_d_);
		    ground_cloud_->clear();
		    no_ground_cloud_->clear();
	        //pointcloud to matrix
	        Eigen::MatrixXf points(point_cloud_->points.size(), 3);
	        int j = 0;
	        #pragma omp for
	        for (const auto &p : point_cloud_->points)
	    	{
	            points.row(j++) << p.x, p.y, p.z;
	        }
	        // ground plane model
	        Eigen::VectorXf result = points * normal_;
	        // threshold filter
	        #pragma omp for
	        for (size_t r = 0; r < result.rows(); ++r)
	        {
	            if (result[r] < th_dist_d_) {
	                ground_cloud_->points.push_back(point_cloud_->points[r]);// means ground
	            }
	            else {
	                no_ground_cloud_->points.push_back(point_cloud_->points[r]);// means not ground 
	            }
	        }
	    }
	    ROS_WARN_STREAM("ground_cloud: "<< ground_cloud_->points.size() << 
	    	       "; no_ground_cloud: " << no_ground_cloud_->points.size());
	    ROS_INFO("[ get no ground cloud ] use %f s", (ros::Time::now() - begin).toSec()); 

	    // 4. Publish no ground points
	    sensor_msgs::PointCloud2 groundless_msg;
	    pcl::toROSMsg(*no_ground_cloud_, groundless_msg);
	    groundless_msg.header.frame_id = "base_link";
        groundless_msg.header.stamp = ros::Time::now();  
	    no_ground_pub_.publish(groundless_msg);  

	    /*!
	     * 5. Its begin to cluster by distance 
	     * cluster the pointcloud according to the distance of the points using different thresholds (not only one for the entire pc)
	     * the scanned point cloud is divided into five pointcloud according to its distance
	     */
	    bbox_candidate_.clear();
	    std::vector<PointCloudPtr> segment_pc_array_(5);
	    #pragma omp for
	    for(size_t i = 0; i < segment_pc_array_.size(); ++i) {
	    	PointCloudPtr tmp(new PointCloud());
	    	segment_pc_array_[i] = tmp;
	    }
	    #pragma omp parallel for
	    for(size_t j = 0; j < no_ground_cloud_->points.size(); ++j)
	    {
	    	pcl::PointXYZ current_point;
	    	current_point.x = no_ground_cloud_->points[j].x;
	        current_point.y = no_ground_cloud_->points[j].y;
	        current_point.z = no_ground_cloud_->points[j].z;

	    	float origin_distance = std::sqrt(std::pow(current_point.x, 2) + std::pow(current_point.y, 2));
	        if (origin_distance > 90 || origin_distance < 0.0 || current_point.y < -10 || 
	        	current_point.y > 10 || current_point.x < -15 || current_point.x > 60  || 
	                    current_point.z < -height_threshold_ || current_point.z > 2.0  ||
	                    								(!pcl_isfinite(origin_distance))) {
	            continue;
	        }
	        //std::cout << "height_threshold_ :" << -height_threshold_ << std::endl;
	        if (origin_distance < seg_distance_[0]) {
	            segment_pc_array_[0]->points.push_back(current_point);
	        }
	        else if (origin_distance < seg_distance_[1]) {
	            segment_pc_array_[1]->points.push_back(current_point);
	        }
	        else if (origin_distance < seg_distance_[2]) {
	            segment_pc_array_[2]->points.push_back(current_point);
	        }
	        else if (origin_distance < seg_distance_[3]) {
	            segment_pc_array_[3]->points.push_back(current_point);
	        }
	        else {
	            segment_pc_array_[4]->points.push_back(current_point);
	        }
	    }

	    //6. Cluster segment
	    //the five pointclouds are clustered by using different radius thresholds, and obstacle centers and Bounding Box are calculated.
	    for(size_t i = 0; i < segment_pc_array_.size(); ++i)
	    {
	    	unsegmented_cloud_->clear();
	    	pcl::copyPointCloud(*segment_pc_array_[i], *unsegmented_cloud_);
	    	// ROS_WARN_STREAM("segment_pc_array[]: "<< segment_pc_array_[i]->points.size() << 
	    	//        "; unsegmented_cloud: " << unsegmented_cloud_->points.size());
	    	#pragma omp for
	    	for(auto &a : unsegmented_cloud_->points)
	    		a.z = 0;
	    	// std::cout << "unsegmented_cloud ::: " << unsegmented_cloud_->points[0].z << " ;" << unsegmented_cloud_->points[0].x << " ;" << unsegmented_cloud_->points[0].y << ";"
	    	//           << unsegmented_cloud_->points[1].z << std::endl;
	    	// kd tree
	    	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>);
	    	if (unsegmented_cloud_->points.size() > 0)
    			tree->setInputCloud(unsegmented_cloud_);
	    	std::vector<pcl::PointIndices> local_indices;

		    pcl::EuclideanClusterExtraction<pcl::PointXYZ> euclid;
		    euclid.setInputCloud(unsegmented_cloud_);
		    euclid.setClusterTolerance(cluster_distance_[i]);
		    euclid.setMinClusterSize(MIN_CLUSTER_SIZE);
		    euclid.setMaxClusterSize(MAX_CLUSTER_SIZE);
		    euclid.setSearchMethod(tree);
		    euclid.extract(local_indices);
		    // calcute the bbox
	        for (size_t j = 0; j < local_indices.size(); ++j)
		    {
		        float min_x = std::numeric_limits<float>::max();
		        float max_x = -std::numeric_limits<float>::max();
		        float min_y = std::numeric_limits<float>::max();
		        float max_y = -std::numeric_limits<float>::max();
		        float min_z = std::numeric_limits<float>::max();
		        float max_z = -std::numeric_limits<float>::max();

		        for (auto pit = local_indices[j].indices.begin(); pit != local_indices[j].indices.end(); ++pit) {
		            //fill new colored cluster point by point
		            pcl::PointXYZ p;
		            p.x = segment_pc_array_[i]->points[*pit].x;
		            p.y = segment_pc_array_[i]->points[*pit].y;
		            p.z = segment_pc_array_[i]->points[*pit].z;

		            if (p.x < min_x)
		                min_x = p.x;
		            if (p.y < min_y)
		                min_y = p.y;
		            if (p.z < min_z)
		                min_z = p.z;
		            if (p.x > max_x)
		                max_x = p.x;
		            if (p.y > max_y)
		                max_y = p.y;
		            if (p.z > max_z)
		                max_z = p.z;
		        }
		        //calculate bounding box 
		        double length = max_x - min_x + 0.2;
		        double width = max_y - min_y + 0.2;
		        double height = max_z - min_z + 0.2;
		        //center coordinate
		        jsk_recognition_msgs::BoundingBox bbox;
		        bbox.pose.position.x = min_x + length / 2;
		        bbox.pose.position.y = min_y + width / 2;
		        bbox.pose.position.z = min_z + height / 2;

		        bbox.dimensions.x = ((length < 0) ? -1 * length : length);
		        bbox.dimensions.y = ((width < 0) ? -1 * width : width);
		        bbox.dimensions.z = ((height < 0) ? -1 * height : height);

		        bbox.header.frame_id = "base_link";
        		bbox.header.stamp = ros::Time::now();  

		        bbox_candidate_.push_back(bbox);
		    }
	    }
	    ROS_WARN_STREAM("bbox_candidate size: " << bbox_candidate_.size());
	    
	    // 7. Publish the detecting bounding box
	    jsk_recognition_msgs::BoundingBoxArray bbox_array;
	    if(!bbox_candidate_.empty()) {
	    	#pragma omp for
	    	for(size_t i = 0; i < bbox_candidate_.size(); ++i)
	    		bbox_array.boxes.push_back(bbox_candidate_[i]);
	    }
	    bbox_array.header.frame_id = "base_link";
        bbox_array.header.stamp = ros::Time::now();  
        detecting_bbox_pub_.publish(bbox_array); 

	}
	//ROS_INFO("---------ending and spinning-------");
	ROS_INFO("[ perception display ] use %f s", (ros::Time::now() - begin).toSec());  

	/*
	// segmentation
	// 创建一个分割器
	pcl::SACSegmentation<pcl::PointXYZ> seg;
	//创建分割时所需要的模型系数对象，coefficients及存储内点的点索引集合对象inliers
    pcl::ModelCoefficients::Ptr coefficients_plane (new pcl::ModelCoefficients ());
	//inliers表示误差能容忍的点 记录的是点云的序号
	pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
	// 可选择配置，设置模型系数需要优化
	seg.setOptimizeCoefficients (true);
	// Mandatory-设置目标几何形状
	seg.setModelType (pcl::SACMODEL_PLANE);
	//分割方法：随机采样法
	seg.setMethodType (pcl::SAC_RANSAC);
	seg.setMaxIterations (1000);
	//设置误差容忍范围(距离阀值)，距离阀值决定了点被认为是局内点是必须满足的条件,表示点到估计模型的距离最大值，
	seg.setDistanceThreshold (0.15);
	//输入点云
	seg.setInputCloud(center_cloud_);
	//分割点云,存储分割结果到点几何inliers及存储平面模型的系数coefficients
	seg.segment (*inliers, *coefficients_plane);
	std::cerr << "Plane coefficients: " << *coefficients_plane << std::endl;
	// Extract the inliers
	pcl::ExtractIndices<pcl::PointXYZ> extract;
	extract.setNegative (true);
    extract.setInputCloud (center_cloud_);
    extract.setIndices (inliers);
    extract.filter (*filter_cloud_);
	
	//Create pointcloud filter
    pcl::CropBox<pcl::PointXYZ> boxFilter;
	boxFilter.setMin(Eigen::Vector4f(x_min_, y_min_, z_min_, 1.0));
	boxFilter.setMax(Eigen::Vector4f(x_max_, y_max_, z_max_, 1.0));
	boxFilter.setInputCloud(center_cloud_);
	boxFilter.setKeepOrganized(true); 
	boxFilter.setUserFilterValue(0.1f); 
	boxFilter.filter(*filter_cloud_);
	ROS_WARN("filter cloud size %ld ", filter_cloud_->points.size());
    */    

}