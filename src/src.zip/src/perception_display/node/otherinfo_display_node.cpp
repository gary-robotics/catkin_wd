/**
 * @file: otherinfo_display_node.cpp
 * @author: Z.H
 * @date: 2019.05.9
 */
#include <ros/ros.h>
#include <tf/tf.h>
#include "perception_display/perception_display.h"

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>

// msgs
#include <sensor_msgs/CompressedImage.h>//camera message
#include <sensor_msgs/Image.h>



ros::Publisher marker_pub;
ros::Publisher text_pub_time;
ros::Publisher text_pub_speed;
ros::Publisher text_pub_imu;
ros::Publisher text_pub_lon;
ros::Publisher text_pub_lat;
ros::Publisher text_pub_h;
ros::Publisher speed_pub;
ros::Publisher image1_pub;

sensor_msgs::ImagePtr msg_1;
int num = 0;

void odomCallback(const nav_msgs::Odometry::ConstPtr &msg)
{
	double lon = msg->pose.pose.position.x;
  	double lat = msg->pose.pose.position.y;
  	double h = tf::getYaw(msg->pose.pose.orientation)*180/M_PI;//unit:du
  	double v = msg->twist.twist.linear.x;//x就是代表前进方向的速度，单位为m/s 

	//publish image
	image1_pub.publish(msg_1); 

	//double lon = 157426.085;
  	//double lat = 417651.434;
  	//double h = 353.88;
  	//double v = 9.12;

  	//std_msgs::Float32 value;
    //++num;
    //if(num > 100) num = 1;
    //value.data = v*(1 + (float)num/100); 
    //speed_pub.publish(value); 


  	time_t tt;
    time( &tt );
    tt = tt + 8*3600;  // transform the time zone
    tm* t= gmtime( &tt );
    char time_text[50];
    char speed_text[50];
    char imu_text[50];
    char lon_text[50];
    char lat_text[50];
    char h_text[50];
    sprintf(time_text, "\n%d-%02d-%02d %02d:%02d:%02d", 
    				   t->tm_year + 1900,
    				   t->tm_mon + 1,
    				   t->tm_mday,
    				   t->tm_hour,
    				   t->tm_min,
    				   t->tm_sec);
    sprintf(speed_text, "\n\n\n%3.2fkm/h\n\n", v*3.6);
    sprintf(imu_text, ".      LON: %9.3f\n.      LAT: %9.3f\n.      H: %6.2f", lon, lat, h);
    sprintf(lon_text, "LON: %9.3f", lon);
    sprintf(lat_text, "LAT: %9.3f", lat);
    sprintf(h_text, "H: %6.2f", h);

    
    /*
    sprintf(text_time, "LON:%9.3f LAT:%9.3f H:%6.2f\nBUS CURRENT SPEED:%3.2fm/s\n%d-%02d-%02d %02d:%02d:%02d\n",
     				   lon,lat,h,v*(1 + (float)num/100),
    				   t->tm_year + 1900,
    				   t->tm_mon + 1,
    				   t->tm_mday,
    				   t->tm_hour,
    				   t->tm_min,
    				   t->tm_sec);
    				   */

    jsk_rviz_plugins::OverlayText t_text_time;
    jsk_rviz_plugins::OverlayText t_text_speed;
    jsk_rviz_plugins::OverlayText t_text_imu;
    jsk_rviz_plugins::OverlayText t_text_lon;
    jsk_rviz_plugins::OverlayText t_text_lat;
    jsk_rviz_plugins::OverlayText t_text_h;

    t_text_time.width = 290;
    t_text_time.height = 80;
  	t_text_time.left = 150;
	t_text_time.top = 688;
	t_text_time.text_size = 16;
	t_text_time.line_width = 3;
	t_text_time.font = "DejaVu Sans Mono";
	t_text_time.text = time_text;
    t_text_time.fg_color.r = 1.0;
    t_text_time.fg_color.g = 1.0;
    t_text_time.fg_color.b = 1.0;
    t_text_time.fg_color.a = 1.0;
    t_text_time.bg_color.r = 0;
    t_text_time.bg_color.g = 0;
    t_text_time.bg_color.b = 0;
    t_text_time.bg_color.a = 0.0;


    t_text_speed.width = 200;
    t_text_speed.height = 200;
  	t_text_speed.left = 205;
	t_text_speed.top = 382;
	t_text_speed.text_size = 18;
	t_text_speed.line_width = 3;
	t_text_speed.font = "DejaVu Sans Mono";
	t_text_speed.text = speed_text;
    t_text_speed.fg_color.r = 1.0;
    t_text_speed.fg_color.g = 1.0;
    t_text_speed.fg_color.b = 1.0;
    t_text_speed.fg_color.a = 1.0;
    t_text_speed.bg_color.r = 0;
    t_text_speed.bg_color.g = 0;
    t_text_speed.bg_color.b = 0;
    t_text_speed.bg_color.a = 0.0;

    t_text_imu.width = 280;
    t_text_imu.height = 100;
  	t_text_imu.left = 130;
	t_text_imu.top = 802;
	t_text_imu.text_size = 15;
	t_text_imu.line_width = 3;
	t_text_imu.font = "DejaVu Sans Mono";
	t_text_imu.text = imu_text;
    t_text_imu.fg_color.r = 1.0;
    t_text_imu.fg_color.g = 1.0;
    t_text_imu.fg_color.b = 1.0;
    t_text_imu.fg_color.a = 1.0;
    t_text_imu.bg_color.r = 0;
    t_text_imu.bg_color.g = 0;
    t_text_imu.bg_color.b = 0;
    t_text_imu.bg_color.a = 0.0;


    t_text_lon.width = 200;
    t_text_lon.height = 50;
  	t_text_lon.left = 160;
	t_text_lon.top = 805;
	t_text_lon.text_size = 15;
	t_text_lon.line_width = 2;
	t_text_lon.font = "DejaVu Sans Mono";
	t_text_lon.text = lon_text;
    t_text_lon.fg_color.r = 1.0;
    t_text_lon.fg_color.g = 1.0;
    t_text_lon.fg_color.b = 1.0;
    t_text_lon.fg_color.a = 1.0;
    t_text_lon.bg_color.r = 0;
    t_text_lon.bg_color.g = 0;
    t_text_lon.bg_color.b = 0;
    t_text_lon.bg_color.a = 0.0;


	t_text_lat.width = 200;
    t_text_lat.height = 50;
  	t_text_lat.left = 160;
	t_text_lat.top = 832;
	t_text_lat.text_size = 15;
	t_text_lat.line_width = 2;
	t_text_lat.font = "DejaVu Sans Mono";
	t_text_lat.text = lat_text;
    t_text_lat.fg_color.r = 1.0;
    t_text_lat.fg_color.g = 1.0;
    t_text_lat.fg_color.b = 1.0;
    t_text_lat.fg_color.a = 1.0;
    t_text_lat.bg_color.r = 0;
    t_text_lat.bg_color.g = 0;
    t_text_lat.bg_color.b = 0;
    t_text_lat.bg_color.a = 0.0;


    t_text_h.width = 200;
    t_text_h.height = 50;
  	t_text_h.left = 160;
	t_text_h.top = 859;
	t_text_h.text_size = 15;
	t_text_h.line_width = 2;
	t_text_h.font = "DejaVu Sans Mono";
	t_text_h.text = h_text;
    t_text_h.fg_color.r = 1.0;
    t_text_h.fg_color.g = 1.0;
    t_text_h.fg_color.b = 1.0;
    t_text_h.fg_color.a = 1.0;
    t_text_h.bg_color.r = 0;
    t_text_h.bg_color.g = 0;
    t_text_h.bg_color.b = 0;
    t_text_h.bg_color.a = 0.0;


    text_pub_time.publish(t_text_time);
    text_pub_speed.publish(t_text_speed);
    text_pub_imu.publish(t_text_imu);
    text_pub_lon.publish(t_text_lon);
    text_pub_lat.publish(t_text_lat);
    text_pub_h.publish(t_text_h);


    // non-essential can not need
    // Publish a lane marker
    visualization_msgs::MarkerArray marker_array;
    visualization_msgs::Marker marker_cylinder;
    visualization_msgs::Marker marker_lane;
    
    marker_lane.header.frame_id = "base_link";
	marker_lane.header.stamp = ros::Time::now();
	marker_lane.ns = "lane";
	marker_lane.color.r = 255;
	marker_lane.color.g = 255;
	marker_lane.color.b = 240;
	marker_lane.color.a = 0.5;
	marker_lane.id = 0;
	marker_lane.type = visualization_msgs::Marker::CUBE;
	marker_lane.action = visualization_msgs::Marker::ADD;
	marker_lane.pose.position.x = 0;
	marker_lane.pose.position.y = 0;
	marker_lane.pose.position.z = -0.15;
	marker_lane.scale.x = 200;
	marker_lane.scale.y = 3.6;
	marker_lane.scale.z = 0.0;

	marker_cylinder.header.frame_id = "base_link";
	marker_cylinder.header.stamp = ros::Time::now();
	marker_cylinder.ns = "cylinder";
	marker_cylinder.color.r = 1.0;
	marker_cylinder.color.g = 0.0;
	marker_cylinder.color.b = 0.0;
	marker_cylinder.color.a = 0.3;
	marker_cylinder.id = 1;
	marker_cylinder.type = visualization_msgs::Marker::CYLINDER;
	marker_cylinder.action = visualization_msgs::Marker::ADD;
	marker_cylinder.pose.position.x = 0;
	marker_cylinder.pose.position.y = 0;
	marker_cylinder.pose.position.z = 0.09;
	marker_cylinder.scale.x = 12;
	marker_cylinder.scale.y = 12;
	marker_cylinder.scale.z = 0.01;
	
	marker_array.markers.push_back(marker_lane);
	marker_array.markers.push_back(marker_cylinder);

	marker_pub.publish(marker_array); 

}


int main(int argc, char *argv[])
{
	cv::Mat image1 = cv::imread("/home/qzkj/Desktop/catkin_qrwd/src/perception_display/images/test2.png", -1);
	msg_1 = cv_bridge::CvImage(std_msgs::Header(), "bgra8", image1).toImageMsg();
	
	ros::init(argc, argv, "otherinfo_display_node");
	ros::NodeHandle nh("~");

	ros::Subscriber odom_sub = nh.subscribe<nav_msgs::Odometry>("odom", 1, odomCallback);

	text_pub_time = nh.advertise<jsk_rviz_plugins::OverlayText>("text_time", 1);
	text_pub_speed = nh.advertise<jsk_rviz_plugins::OverlayText>("text_speed", 1);
	text_pub_imu = nh.advertise<jsk_rviz_plugins::OverlayText>("text_imu", 1);
	text_pub_lon = nh.advertise<jsk_rviz_plugins::OverlayText>("text_lon", 1);
	text_pub_lat = nh.advertise<jsk_rviz_plugins::OverlayText>("text_lat", 1);
	text_pub_h = nh.advertise<jsk_rviz_plugins::OverlayText>("text_h", 1);

	marker_pub = nh.advertise<visualization_msgs::MarkerArray>("visualization_marker", 1);
	image1_pub = nh.advertise<sensor_msgs::Image>("image_raw_1", 1);
	   
	ros::spin();

	return 0;
}

