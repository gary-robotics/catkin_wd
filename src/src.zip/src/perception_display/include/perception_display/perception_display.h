/**
 * @file: perception_display.h
 * @author: Z.H
 * @date: 2019.05.9
 */
#pragma once

//C++
#include <iostream>
#include <math.h>
#include <string>
#include <vector>
#include <stdio.h>
#include <mutex>
#include <time.h>
#include <omp.h>


//ROS
#include <ros/ros.h>
#include <tf/tf.h>
#include "Eigen/Dense"

// msgs
#include <sensor_msgs/PointCloud2.h>
#include <jsk_recognition_msgs/BoundingBox.h>
#include <jsk_recognition_msgs/BoundingBoxArray.h>
#include <jsk_rviz_plugins/OverlayText.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float32.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

// pcl
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#include <pcl/common/common.h>
#include <pcl/common/centroid.h>
#include <pcl_ros/transforms.h>
#include <pcl/search/organized.h>
#include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/ModelCoefficients.h>

#include <pcl/conversions.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/filters/filter.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/crop_box.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/extract_indices.h>

#include <pcl/sample_consensus/method_types.h>  
#include <pcl/sample_consensus/model_types.h>  
#include <pcl/segmentation/extract_clusters.h>  
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/conditional_euclidean_clustering.h>

#define MIN_CLUSTER_SIZE 20
#define MAX_CLUSTER_SIZE 5000

typedef pcl::PointCloud<pcl::PointXYZ> PointCloud;
typedef pcl::PointCloud<pcl::PointXYZ>::Ptr PointCloudPtr;
typedef pcl::PointCloud<pcl::PointXYZ>::ConstPtr PointCloudConstPtr;


class PerceptionDisplay
{
public:

	PerceptionDisplay();

	~PerceptionDisplay();


    void subPointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr &msg);

    
private:

	//ros interface
	ros::NodeHandle n_;
    ros::Subscriber point_cloud_sub_;
    ros::Publisher no_ground_pub_;
    ros::Publisher detecting_bbox_pub_;


	//topic
    std::string point_cloud_topic_;
    std::string no_ground_topic_;
    std::string detecting_bbox_topic_;

    PointCloudPtr point_cloud_;
    PointCloudPtr seed_cloud_;
    PointCloudPtr ground_cloud_;
    PointCloudPtr no_ground_cloud_;
    PointCloudPtr unsegmented_cloud_;

    //plane ground filter param
    Eigen::MatrixXf normal_;
    float d_, th_dist_d_;
    float lidar_height_;
    float height_threshold_;

    //segment
    std::vector<float> seg_distance_, cluster_distance_;
    std::vector<jsk_recognition_msgs::BoundingBox> bbox_candidate_;
    
};
