/**
 * @file: odom_pub_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "ros/ros.h"

#include <iostream>
#include <stdint.h>
#include <math.h>
#include <string>
#include <csignal>
#include <cstdio>

#include <can_to_eth/c2e.h>
#include <can_to_eth/can_data.h>
#include <tf/transform_broadcaster.h>


#include "std_msgs/UInt32.h"
#include <nav_msgs/Odometry.h>

//----------z.h--------------------//
//Transform the coordinate system from IMU installation position to vehicle front axle center
//#define TRANS_X -57291.78 - 2
#define TRANS_X 0
//#define TRANS_Y 4453577.394 + 3
#define TRANS_Y 0
//----------z.h-------------------//


ODOM_PUB::ODOM_PUB() 
{
}

ODOM_PUB::~ODOM_PUB()
{
}

int gate00,gate01,gate02,gate03;


void ODOM_PUB::ParseData(CAN_MESSAGE &canmessge)
{
    CAN_STRUCT Temp_can;
    int t_state,t_heading,t_temp;
    long t_latitude,t_logitude;

    Temp_can.can_info = canmessge.can_data[0];
    Temp_can.can_id = 0;
    for(int i=1;i<5;i++)
    {
        Temp_can.can_id <<= 8;
        Temp_can.can_id |= canmessge.can_data[i];
    }
    ROS_INFO("[Z.H]IPC parses the data sent by the bottom CAN, and can_id is: %#X",Temp_can.can_id);

    for(int i=0;i<8;i++)
    {
        Temp_can.can_data[i] = canmessge.can_data[i+5];
    }

    /*
    for(int i=0;i<8;i++)
    {
        ROS_INFO("canmessge: %d",Temp_can.can_data[i]);
    }
    */  
    switch(Temp_can.can_id)
    {
        case 0x40b:
            t_heading = 0;
            gps_state = Temp_can.can_data[3];
            t_heading = (((int)Temp_can.can_data[2])<<8) | Temp_can.can_data[1] ;
            vel_heading = (double)t_heading/100 ;
            ROS_INFO("[Z.H]PARSE 0x40B: gps_state:%d; vel_heading: %.3f", gps_state, vel_heading);
            GPSAliveTime = ros::Time::now();
            break;

        case 0x30b:
            t_latitude = 0;
            for(int i=3;i>=0;i--)
            {
                t_latitude <<= 8;
                t_latitude |= Temp_can.can_data[i];
            }
            vel_position_x = t_latitude;
            t_logitude = 0;
            for(int i=7;i>3;i--)
            {
                t_logitude <<= 8;
                t_logitude |= Temp_can.can_data[i];
            }
            vel_position_y = t_logitude;
            ROS_INFO("[Z.H]PARSE 0x30B: t_latitude: %ld, t_logitude: %ld",t_latitude,t_logitude);
            GPSAliveTime = ros::Time::now();

            // low prass filter
            static double last_x = 0;
            static double last_y = 0;
            vel_position_x = filter_rate0 * last_x + (1-filter_rate0) * vel_position_x;
            vel_position_y = filter_rate0 * last_y + (1-filter_rate0) * vel_position_y;
            last_x = vel_position_x;
            last_y = vel_position_y;

            static double llast_x = 0;
            static double llast_y = 0;
            vel_position_x = filter_rate1 * llast_x + (1-filter_rate1) * vel_position_x;
            vel_position_y = filter_rate1 * llast_y + (1-filter_rate1) * vel_position_y;
            llast_x = vel_position_x;
            llast_y = vel_position_y;

            break;

        case 0x91:
        
            gate00 = int(Temp_can.can_data[0]); // Driving Mode
            gate01 = int(Temp_can.can_data[1]); // acc
            gate02 = int(Temp_can.can_data[2]); // dec
            gate03 = int(Temp_can.can_data[7]); // SpeedCounter
            car_counter += gate03;
            if(car_counter > 255)
                car_counter = 0;

            t_temp = (((int)Temp_can.can_data[3]<<8) | Temp_can.can_data[4]) ;
            vel_speed =  ((double)t_temp)/256/3.6;
            current_steering_angle = (double)((Temp_can.can_data[5]<<8) | Temp_can.can_data[6]);
            ROS_INFO("[Z.H]PARSE 0x91: vel_speed: %f km/h, feedback_steering_angle: %f du", vel_speed*3.6, current_steering_angle);
            break;
    }    
}

void ODOM_PUB::PID_params_change()
{
    float v = vel_speed*3.6;
    if(v > 20)
    {
        Kp_th_f = Kp_th_1;
        Ki_th_f = Ki_th_1;
        Kp_b_f = Kp_b_2;
    }
    else if((v>10&&v<16))
    {
        Kp_th_f = Kp_th_2;
        Ki_th_f = Ki_th_2;
        Kp_b_f = Kp_b_3;
    }
    else if((v>17&&v<18))
    {
        Kp_th_f = Kp_th_2;
        Ki_th_f = Ki_th_2;
        Kp_b_f = Kp_b_3;
    }
    else if(v>7&&v<10)
    {
        Kp_th_f = Kp_th_3;
        Ki_th_f = Ki_th_3;
        Kp_b_f = Kp_b_3;
    }
    else if(v>18&&v<20)
    {
        Kp_b_f = Kp_b_3;
    }
    else if(v>25)
    {
        Kp_b_f = Kp_b_1;
    }
    else
    {
        Kp_th_f = Kp_th;
        Ki_th_f = Ki_th;
        Kp_b_f = Kp_b-0.2;
    }
}

void ODOM_PUB::pub_cmd_down(void)
{
    static unsigned char counter=0;
    can_to_eth::can_data pub_data;

    counter++;  

    PID_params_change();

    memset(&pub_data.can_data[0],0,13);
    pub_data.can_data[0] = 8;
    pub_data.can_data[1] = 0;
    pub_data.can_data[2] = 0;
    pub_data.can_data[3] = 0x05;
    pub_data.can_data[4] = 0x00;
    pub_data.can_data[5] = targetWorkMode;//cmd_set 0 hand 2 AD // 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
    pub_data.can_data[6] = 2; //low level filter
    pub_data.can_data[7] = static_cast<uint8_t>((static_cast<uint16_t>(targetSpeed*10+5000)>>8) & 0xff);
    pub_data.can_data[8] = static_cast<uint8_t>(static_cast<uint16_t>(targetSpeed*10+5000)&0xff);
    pub_data.can_data[9] = Kp_th_f; //Kp_th
    pub_data.can_data[10] = Kd_th; //Kd_th
    pub_data.can_data[11] = Kp_b_f; //Kp_b
    pub_data.can_data[12] = Kd_b; //Kd_b
    can_pub.publish(pub_data);

    memset(&pub_data.can_data[0],0,13);
    pub_data.can_data[0] = 8;
    pub_data.can_data[1] = 0;
    pub_data.can_data[2] = 0;
    pub_data.can_data[3] = 0x04;
    pub_data.can_data[4] = 0xff;
    pub_data.can_data[6]=static_cast<uint8_t>((static_cast<int16_t>((targetSteeringAngle/10+2048)*16) >> 8) & 0xff);;
    pub_data.can_data[7]=static_cast<uint8_t>((static_cast<int16_t>((targetSteeringAngle/10+2048)*16)) & 0xff);
    pub_data.can_data[8]=targetSteeringVelocity&0xff;
    pub_data.can_data[9] = 20; // 方向盘最大转角速度
    // pub_data.can_data[10] = Kd_b; //Kd_b
    pub_data.can_data[12] = counter;
    can_pub.publish(pub_data);

    ROS_INFO_STREAM("[Z.H]IPC will send info to the bottom CAN are:\n" 
                   << " targetWorkMode: " << targetWorkMode
                   << " targetSpeed: " << targetSpeed << "km/h"
                   << " targetSteeringAngle: " << targetSteeringAngle/10);
    counter %= 255;
}

/*
void ODOM_PUB::pub_cmd_down1(void)//(ros::Publisher &Temp_pub,ODOM_PUB *cmd_rev)
{
  static unsigned char counter=0;
  can_to_eth::can_data pub_data;
  ROS_INFO("Publishing direct control .....");
  counter++;
  double limit_upper = 2000;
  double limit_lower = -2000;

  targetSpeed = (targetSpeed>limit_lower) ? targetSpeed:limit_lower;
  targetSpeed = (targetSpeed<limit_upper) ? targetSpeed:limit_upper;

  memset(&pub_data.can_data[0],0,13);
  // AS_FEED
  pub_data.can_data[0] = 8;
  pub_data.can_data[1] = 0;
  pub_data.can_data[2] = 0;
  pub_data.can_data[3] = (SteeringIDArray[2] >> 8) & 0xFF;
  pub_data.can_data[4] = SteeringIDArray[2] & 0xFF;
  pub_data.can_data[6] = 0x10;
  can_pub2.publish(pub_data);

  memset(&pub_data.can_data[0],0,13);
  //AS_CONTROL
  pub_data.can_data[0] = 8;
  pub_data.can_data[1] = 0;
  pub_data.can_data[2] = 0;
  pub_data.can_data[3] = (SteeringIDArray[0] >> 8) & 0xFF;
  pub_data.can_data[4] = SteeringIDArray[0] & 0xFF;
  pub_data.can_data[6] = (tempWorkMode & 0x01) << 3;
	pub_data.can_data[9] = static_cast<uint8_t>((static_cast<int16_t>((-targetSteeringAngle/10+2048)*16) >> 8) & 0xff);
	pub_data.can_data[10] = static_cast<uint8_t>((static_cast<int16_t>((-targetSteeringAngle/10+2048)*16)) & 0xff);
	pub_data.can_data[11] = static_cast<uint8_t>(targetSteeringVelocity/4.0);
  can_pub2.publish(pub_data);

  memset(&pub_data.can_data[0],0,13);
  //EHB_Control_R
  pub_data.can_data[0] = 8;
  pub_data.can_data[1] = 0;
  pub_data.can_data[2] = 0;
  pub_data.can_data[3] = (EHBIDArray[0] >> 8) & 0xFF;
  pub_data.can_data[4] = EHBIDArray[0] & 0xFF;
  pub_data.can_data[5] = tempWorkMode & 0x01;
	pub_data.can_data[6] = static_cast<uint8_t>(static_cast<int16_t>(targetBrakePressure) & 0xff );
  can_pub2.publish(pub_data);

  memset(&pub_data.can_data[0],0,13);
  //EHB_Control_L
  pub_data.can_data[0] = 8; // data length 8
  pub_data.can_data[1] = 0;
  pub_data.can_data[2] = 0;
  pub_data.can_data[3] = (EHBIDArray[1] >> 8) & 0xFF;
  pub_data.can_data[4] = EHBIDArray[1] & 0xFF;
  pub_data.can_data[5] = tempWorkMode & 0x01;
	pub_data.can_data[6] = static_cast<uint8_t>(static_cast<int16_t>(targetBrakePressure) & 0xff );
  can_pub2.publish(pub_data);

  // memset(&pub_data.can_data[0],0,13);
  // //VCU
  // pub_data.can_data[0] = 0x88; // extended, data length 8
  // pub_data.can_data[1] = (VCUIDArray[0] >> 24) & 0xFF;;
  // pub_data.can_data[2] = (VCUIDArray[0] >> 16) & 0xFF;;
  // pub_data.can_data[3] = (VCUIDArray[0] >> 8) & 0xFF;
  // pub_data.can_data[4] = VCUIDArray[0] & 0xFF;
  // pub_data.can_data[5] = static_cast<uint8_t>(tempWorkMode & 0x01 +  (tempWorkMode << 2) & 0x1100);
	// pub_data.can_data[6] = static_cast<uint8_t>(static_cast<int16_t>(limit_lower/4) & 0xff );
	// pub_data.can_data[7] = static_cast<uint8_t>((static_cast<int16_t>(limit_lower/4)>>8) & 0x0f + static_cast<int16_t>(limit_upper/4) & 0x0f );
	// pub_data.can_data[8] = static_cast<uint8_t>(((static_cast<int16_t>(limit_upper/4) & 0x111111110000)>>4) & 0xff );
	// pub_data.can_data[8] = static_cast<uint8_t>(static_cast<int16_t>(targetSpeed+5000) & 0xff );
	// pub_data.can_data[9] = static_cast<uint8_t>((static_cast<int16_t>(targetSpeed+5000)>>8) & 0xff );
  // can_pub1.publish(pub_data);

  counter %= 255;
}
*/
void ODOM_PUB::pub_set_up(void)
{
    std_msgs::Float64 decision_msg;
    decision_msg.data = current_steering_angle;
    decision_pub.publish(decision_msg);
}

void ODOM_PUB::pub_odom(void)
{
    
    double x = 0; 
    double y = 0;
    double th = 0;
    
    double vx = vel_speed;  
    double vy = 0;
    double vth = 0;
    
    gaussConvert(x,y);

    th = vel_heading;
    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(th*M_PI/180);
    /*
    //tf::TransformBroadcaster broadcaster;
    geometry_msgs::TransformStamped odom_trans;
    odom_trans.header.frame_id = "odom";
	odom_trans.child_frame_id = "base_link";
	odom_trans.header.stamp = current_time; 
	odom_trans.transform.translation.x = x; 
	odom_trans.transform.translation.y = y; 
	odom_trans.transform.translation.z = 0.0;
    odom_trans.transform.rotation = odom_quat;
    broadcaster.sendTransform(odom_trans);
	odom_trans.transform.rotation = tf::createQuaternionMsgFromYaw(th);
    //publishing the odometry and the new tf
    broadcaster.sendTransform(odom_trans);
    */   
    
    //Transform the coordinate system from IMU installation position to vehicle front axle center
    x += TRANS_X;//Unit m // left + right -
    y += TRANS_Y;
    ROS_INFO("[Z.H]ODOM: IPC receive locate info from bottom can and trans to front axle center are:\nLON: %.3f LAT: %.3f, Heading: %.3f", x, y, vel_heading);

    //publish odom msg
	nav_msgs::Odometry odom;
	odom.header.stamp = ros::Time::now();
	odom.header.frame_id = "odom";
	odom.child_frame_id = "base_link";
	    
	odom.pose.pose.position.x = x;
	odom.pose.pose.position.y = y;
	odom.pose.pose.position.z = gps_state;
    odom.pose.pose.orientation = odom_quat;
	odom.twist.twist.linear.x = vx;
	odom.twist.twist.linear.y = vy;
	odom.twist.twist.linear.z = 0.0;
	odom.twist.twist.angular.x = 0.0;
	odom.twist.twist.angular.y = 0.0;
	odom.twist.twist.angular.z = vth;

	odom_pub.publish(odom);
}


void velcmd_Callback(const std_msgs::Float64MultiArray::ConstPtr& msg, ODOM_PUB *cmd_rev)
{
    float Temp_cmd[9];

    for(int i=0;i<9;i++)      
        Temp_cmd[i] = msg->data[i];
    /**
     *@brief: only when both GPS and Lidar are good, the targetWorkMode = 2 
     *@param: 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
     */
    cmd_rev->targetWorkMode =(unsigned int)Temp_cmd[0];
    cmd_rev->targetSpeed =(double)(Temp_cmd[1]*3.6);
    cmd_rev->targetSteeringAngle = (double)Temp_cmd[2]*10; //actual steering angle * 10
    cmd_rev->targetSteeringVelocity = (short)Temp_cmd[3]/4;
    cmd_rev->b_pos_isValid = 0;
    cmd_rev->x_ui = 0;
    cmd_rev->y_ui = 0;
    cmd_rev->targetBrakePressure = 0;
    cmd_rev->tempWorkMode = 0;

    cmd_rev->cmdReceivedTime = ros::Time::now();
}




void CanRec_Callback(const can_to_eth::can_data::ConstPtr &msg,ODOM_PUB *port)
{
    can_to_eth::can_data temp_tx_canmessge = *msg;
    CAN_MESSAGE temp_canmessge;
    memcpy(temp_canmessge.can_data,(unsigned char*)&temp_tx_canmessge,13);
    port->can_Rmessage.push_back(temp_canmessge);
}

void lidarHeartCallback(const std_msgs::UInt32::ConstPtr& msg_ptr, ODOM_PUB* cmd_rev_ptr)
{
    static int last_heart_beat = 0;
    cmd_rev_ptr->lidar_status = 1;
    cmd_rev_ptr->heart_count = msg_ptr->data;
    if(cmd_rev_ptr->heart_count == last_heart_beat)
    {
        cmd_rev_ptr->lidar_status = 0;
    }
    else
    {
        cmd_rev_ptr->lidarAliveTime = ros::Time::now();
    }
    cmd_rev_ptr->lidarReceivedTime = ros::Time::now();
    last_heart_beat = cmd_rev_ptr->heart_count;
}

void carStatusCheck(ODOM_PUB* cmd_rev_ptr)
{
    static int last_car_counter = 0;
    cmd_rev_ptr->car_status = 1;
    if(cmd_rev_ptr->car_init == 0)
    {
        cmd_rev_ptr->carAliveTime = ros::Time::now();
        cmd_rev_ptr->car_init = 1;
    }

    if(cmd_rev_ptr->car_counter == last_car_counter)
    {
        cmd_rev_ptr->car_status = 0;
    }
    else
    {
        cmd_rev_ptr->carAliveTime = ros::Time::now();
    }
    cmd_rev_ptr->carReceivedTime = ros::Time::now();
    last_car_counter = cmd_rev_ptr->car_counter;
}

void ODOM_PUB::set_params(ros::NodeHandle nh)
{
    ROS_INFO("[Z.H] now begin to set odom_pub_node params ~~");

    nh.param("Kp_th", Kp_th, double(225));
    ros::param::get("~Kp_th",Kp_th);
    nh.param("Ki_th", Ki_th, double(10));
    ros::param::get("~Ki_th",Ki_th);
    nh.param("Kd_th", Kd_th, double(0));
    ros::param::get("~Kd_th",Kd_th);
    nh.param("Kp_b", Kp_b, double(25));
    ros::param::get("~Kp_b",Kp_b);
    nh.param("Ki_b", Ki_b, double(0));
    ros::param::get("~Ki_b",Ki_b);
    nh.param("Kd_b", Kd_b, double(10));
    ros::param::get("~Kd_b",Kd_b);

    ROS_INFO("[Z.H]load launch file PID params are:\n[throttle]:Kp_th:%.1f, Ki_th:%.1f, Kd_th:%.1f\n[  brake ]:Kp_b:%.1f, Ki_b:%.1f, Kd_b:%.1f", Kp_th, Ki_th, Kd_th, Kp_b, Ki_b, Kd_b);

    Kp_th_1 = Kp_th+4.5;
    Kp_th_2 = Kp_th+0.42;
    Kp_th_3 = Kp_th+0.38;
    Kp_th_4 = Kp_th-0.7;     

    Ki_th_1 = Ki_th+0.5;
    Ki_th_2 = Ki_th+0.05;
    Ki_th_3 = Ki_th+0.06;
    Ki_th_4 = Ki_th+0.15;

    Kp_b_1 = Kp_b+3.0;
    Kp_b_2 = Kp_b+1.5;
    Kp_b_3 = Kp_b+0.1;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "vehicle_ctrl");
    ODOM_PUB vel_ctrl;
    ros::NodeHandle nh;

    vel_ctrl.set_params(nh);

    ros::Subscriber decision_sub = nh.subscribe<std_msgs::Float64MultiArray>("decision_pub", 10,boost::bind(velcmd_Callback,_1,&vel_ctrl));
    ros::Subscriber can_sub1 = nh.subscribe<can_to_eth::can_data>("can2net1", 50, boost::bind(CanRec_Callback,_1,&vel_ctrl));
    ros::Subscriber can_sub2 = nh.subscribe<can_to_eth::can_data>("can2net2", 50, boost::bind(CanRec_Callback,_1,&vel_ctrl));
    ros::Subscriber lidar_heart_sub = nh.subscribe<std_msgs::UInt32>("HeartBeat", 50,boost::bind(lidarHeartCallback,_1,&vel_ctrl));

    vel_ctrl.odom_pub = nh.advertise<nav_msgs::Odometry>("odom", 10);
    vel_ctrl.decision_pub =nh.advertise<std_msgs::Float64>("decision_sub", 10);
    vel_ctrl.can_pub = nh.advertise<can_to_eth::can_data>("net2can", 10);
    
    CAN_MESSAGE temp_canmessge;
    //can_to_eth::can_data temp_rx_canmessge;

    ros::Rate loop_rate(500);
    ros::Time old_time = ros::Time::now();
    vel_ctrl.GPSAliveTime = ros::Time::now();

    while(ros::ok())
    {
        ros::Time now_time = ros::Time::now();
        while(!vel_ctrl.can_Rmessage.empty())
        {
            temp_canmessge = vel_ctrl.can_Rmessage.front();
            //memcpy((unsigned char*)&temp_rx_canmessge,temp_canmessge.can_data,13);
            vel_ctrl.ParseData(temp_canmessge);
            vel_ctrl.can_Rmessage.erase(vel_ctrl.can_Rmessage.begin());
        }

        if((now_time-old_time).toSec() >= 0.05)
        {
            ROS_INFO("[Z.H]now its begin to publish odom/decision/cmd info~~");
            carStatusCheck(&vel_ctrl);
            /*
            if((vel_ctrl.lidar_status == 0||vel_ctrl.lidar_status == 1)
                &&(((ros::Time::now().toSec()-vel_ctrl.lidarReceivedTime.toSec())>1)
                ||(ros::Time::now().toSec()-vel_ctrl.lidarAliveTime.toSec()>1)))
            {
                ROS_ERROR("[Z.H]lidar DIED!!!");
            }
            */

            if((ros::Time::now().toSec()-vel_ctrl.cmdReceivedTime.toSec())>1){
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO planning_control info received, please check planning_control!!!");
            }
            if((((ros::Time::now().toSec()-vel_ctrl.carReceivedTime.toSec())>5)
                 ||(ros::Time::now().toSec()-vel_ctrl.carAliveTime.toSec()>5)))
            {
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO car status info, please check car!!!");    
            }

            if((now_time.toSec()-vel_ctrl.GPSAliveTime.toSec())>2)
            {
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO GPS info, please check gps!!!");
            }

            vel_ctrl.pub_odom();
            vel_ctrl.pub_cmd_down();
            vel_ctrl.pub_set_up();

            old_time  = now_time;
        }
        ros::spinOnce();
        loop_rate.sleep();    
    }
    return 0;
}
